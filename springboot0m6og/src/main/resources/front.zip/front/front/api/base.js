﻿const base = {
    url : "http://localhost:8080/springboot0m6og/"
}
export default base
